#define WIZARD_GLADE_CONTENTS "\
<\?xml version=\"1.0\" encoding=\"UTF-8\"\?>\
<!-- Generated with glade 3.19.0 -->\
<interface>\
  <requires lib=\"gtk+\" version=\"3.10\"/>\
  <object class=\"GtkImage\" id=\"image1\">\
    <property name=\"visible\">True</property>\
    <property name=\"can_focus\">False</property>\
    <property name=\"icon_name\">media-record-symbolic</property>\
  </object>\
  <object class=\"GtkListStore\" id=\"ls_sensitive_words\">\
    <columns>\
      <!-- column-name file -->\
      <column type=\"gchararray\"/>\
      <!-- column-name data -->\
      <column type=\"gchararray\"/>\
      <!-- column-name search_item -->\
      <column type=\"gpointer\"/>\
    </columns>\
  </object>\
  <object class=\"GtkBox\" id=\"page_3\">\
    <property name=\"orientation\">vertical</property>\
    <property name=\"visible\">True</property>\
    <property name=\"can_focus\">False</property>\
    <property name=\"hexpand\">True</property>\
    <property name=\"vexpand\">True</property>\
    <property name=\"spacing\">3</property>\
    <child>\
      <object class=\"GtkLabel\" id=\"label8\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <property name=\"halign\">start</property>\
        <property name=\"valign\">start</property>\
        <property name=\"label\" translatable=\"yes\">Please review the data before it gets reported. Depending on reporter chosen, it may end up publicly visible.</property>\
        <property name=\"wrap\">True</property>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">0</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkPaned\" id=\"paned1\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">True</property>\
        <property name=\"orientation\">vertical</property>\
        <child>\
          <object class=\"GtkNotebook\" id=\"notebook_edit\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">True</property>\
            <property name=\"hexpand\">True</property>\
            <property name=\"vexpand\">True</property>\
            <property name=\"scrollable\">True</property>\
            <child>\
              <placeholder/>\
            </child>\
            <child type=\"tab\">\
              <placeholder/>\
            </child>\
            <child>\
              <placeholder/>\
            </child>\
            <child type=\"tab\">\
              <placeholder/>\
            </child>\
            <child>\
              <placeholder/>\
            </child>\
            <child type=\"tab\">\
              <placeholder/>\
            </child>\
          </object>\
          <packing>\
            <property name=\"resize\">True</property>\
            <property name=\"shrink\">True</property>\
          </packing>\
        </child>\
        <child>\
          <object class=\"GtkExpander\" id=\"expander_search\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">True</property>\
            <property name=\"border_width\">1</property>\
            <child>\
              <object class=\"GtkBox\" id=\"box7\">\
                <property name=\"visible\">True</property>\
                <property name=\"can_focus\">False</property>\
                <property name=\"orientation\">vertical</property>\
                <child>\
                  <object class=\"GtkBox\" id=\"box8\">\
                    <property name=\"visible\">True</property>\
                    <property name=\"can_focus\">False</property>\
                    <child>\
                      <object class=\"GtkRadioButton\" id=\"rb_forbidden_words\">\
                        <property name=\"label\" translatable=\"yes\">Sensitive words</property>\
                        <property name=\"visible\">True</property>\
                        <property name=\"can_focus\">True</property>\
                        <property name=\"receives_default\">False</property>\
                        <property name=\"halign\">start</property>\
                        <property name=\"active\">True</property>\
                        <property name=\"draw_indicator\">True</property>\
                      </object>\
                      <packing>\
                        <property name=\"expand\">False</property>\
                        <property name=\"fill\">True</property>\
                        <property name=\"position\">0</property>\
                      </packing>\
                    </child>\
                    <child>\
                      <object class=\"GtkRadioButton\" id=\"rb_custom_search\">\
                        <property name=\"label\" translatable=\"yes\">Custom</property>\
                        <property name=\"visible\">True</property>\
                        <property name=\"can_focus\">True</property>\
                        <property name=\"receives_default\">False</property>\
                        <property name=\"halign\">start</property>\
                        <property name=\"draw_indicator\">True</property>\
                        <property name=\"group\">rb_forbidden_words</property>\
                      </object>\
                      <packing>\
                        <property name=\"expand\">False</property>\
                        <property name=\"fill\">True</property>\
                        <property name=\"position\">1</property>\
                      </packing>\
                    </child>\
                    <child>\
                      <object class=\"GtkEntry\" id=\"entry_search_bt\">\
                        <property name=\"visible\">True</property>\
                        <property name=\"sensitive\">False</property>\
                        <property name=\"can_focus\">True</property>\
                        <property name=\"has_tooltip\">True</property>\
                        <property name=\"invisible_char\">●</property>\
                        <property name=\"secondary_icon_name\">edit-find-symbolic</property>\
                        <property name=\"primary_icon_activatable\">False</property>\
                        <property name=\"secondary_icon_tooltip_text\" translatable=\"yes\">Clear the search bar to see the list of security sensitive words.</property>\
                        <property name=\"secondary_icon_tooltip_markup\" translatable=\"yes\">Clear the search bar to see the list of security sensitive words.</property>\
                      </object>\
                      <packing>\
                        <property name=\"expand\">True</property>\
                        <property name=\"fill\">True</property>\
                        <property name=\"position\">2</property>\
                      </packing>\
                    </child>\
                  </object>\
                  <packing>\
                    <property name=\"expand\">False</property>\
                    <property name=\"fill\">True</property>\
                    <property name=\"position\">0</property>\
                  </packing>\
                </child>\
                <child>\
                  <object class=\"GtkScrolledWindow\" id=\"scrolledwindow1\">\
                    <property name=\"visible\">True</property>\
                    <property name=\"can_focus\">True</property>\
                    <property name=\"hexpand\">True</property>\
                    <property name=\"vexpand\">True</property>\
                    <property name=\"shadow_type\">in</property>\
                    <child>\
                      <object class=\"GtkTreeView\" id=\"tv_sensitive_words\">\
                        <property name=\"visible\">True</property>\
                        <property name=\"can_focus\">True</property>\
                        <property name=\"model\">ls_sensitive_words</property>\
                        <property name=\"headers_visible\">False</property>\
                        <property name=\"headers_clickable\">False</property>\
                        <property name=\"enable_search\">False</property>\
                        <property name=\"search_column\">0</property>\
                        <property name=\"enable_grid_lines\">both</property>\
                        <property name=\"enable_tree_lines\">True</property>\
                        <child internal-child=\"selection\">\
                          <object class=\"GtkTreeSelection\" id=\"tv_sensitive_words_selection\"/>\
                        </child>\
                        <child>\
                          <object class=\"GtkTreeViewColumn\" id=\"treeviewcolumn1\">\
                            <property name=\"resizable\">True</property>\
                            <property name=\"title\" translatable=\"yes\">file</property>\
                            <child>\
                              <object class=\"GtkCellRendererText\" id=\"cellrenderertext1\"/>\
                              <attributes>\
                                <attribute name=\"text\">0</attribute>\
                              </attributes>\
                            </child>\
                          </object>\
                        </child>\
                        <child>\
                          <object class=\"GtkTreeViewColumn\" id=\"treeviewcolumn2\">\
                            <property name=\"resizable\">True</property>\
                            <property name=\"title\" translatable=\"yes\">data</property>\
                            <child>\
                              <object class=\"GtkCellRendererText\" id=\"crt_sensitive_word_value\"/>\
                              <attributes>\
                                <attribute name=\"markup\">1</attribute>\
                              </attributes>\
                            </child>\
                          </object>\
                        </child>\
                      </object>\
                    </child>\
                  </object>\
                  <packing>\
                    <property name=\"expand\">True</property>\
                    <property name=\"fill\">True</property>\
                    <property name=\"position\">1</property>\
                  </packing>\
                </child>\
              </object>\
            </child>\
            <child type=\"label\">\
              <object class=\"GtkLabel\" id=\"label12\">\
                <property name=\"visible\">True</property>\
                <property name=\"can_focus\">False</property>\
                <property name=\"label\" translatable=\"yes\">Search</property>\
              </object>\
            </child>\
          </object>\
          <packing>\
            <property name=\"resize\">True</property>\
            <property name=\"shrink\">True</property>\
          </packing>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">True</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">1</property>\
      </packing>\
    </child>\
  </object>\
  <object class=\"GtkBox\" id=\"page_0\">\
    <property name=\"orientation\">vertical</property>\
    <property name=\"visible\">True</property>\
    <property name=\"can_focus\">False</property>\
    <property name=\"border_width\">3</property>\
    <property name=\"spacing\">3</property>\
    <child>\
      <object class=\"GtkLabel\" id=\"lbl_cd_reason\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <property name=\"halign\">start</property>\
        <property name=\"valign\">start</property>\
        <property name=\"wrap\">True</property>\
        <attributes>\
          <attribute name=\"style\" value=\"normal\"/>\
          <attribute name=\"weight\" value=\"bold\"/>\
          <attribute name=\"foreground\" value=\"#ffff00000000\"/>\
        </attributes>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">0</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkLabel\" id=\"label7\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <property name=\"halign\">start</property>\
        <property name=\"valign\">start</property>\
        <property name=\"label\" translatable=\"yes\">On the following screens, you will be asked to describe how the problem occurred, to choose how to analyze the problem (if needed), to review collected data, and to choose where the problem should be reported. Click 'Forward' to proceed.</property>\
        <property name=\"wrap\">True</property>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">1</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkExpander\" id=\"expander1\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">True</property>\
        <child>\
          <object class=\"GtkScrolledWindow\" id=\"container_details1\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">True</property>\
            <property name=\"shadow_type\">out</property>\
            <child>\
              <placeholder/>\
            </child>\
          </object>\
        </child>\
        <child type=\"label\">\
          <object class=\"GtkLabel\" id=\"dump_elements\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
            <property name=\"label\" translatable=\"yes\">Details</property>\
          </object>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">True</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">2</property>\
      </packing>\
    </child>\
  </object>\
  <object class=\"GtkBox\" id=\"page_2\">\
    <property name=\"orientation\">vertical</property>\
    <property name=\"visible\">True</property>\
    <property name=\"can_focus\">False</property>\
    <property name=\"border_width\">10</property>\
    <property name=\"spacing\">3</property>\
    <child>\
      <object class=\"GtkLabel\" id=\"label1\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <property name=\"halign\">start</property>\
        <property name=\"valign\">start</property>\
        <property name=\"label\" translatable=\"yes\">How did this problem happen (step-by-step)\? How can it be reproduced\? Any additional comments useful for diagnosing the problem\? Please use English if possible.</property>\
        <property name=\"wrap\">True</property>\
        <property name=\"xalign\">0</property>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">0</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkScrolledWindow\" id=\"scrolledwindow4\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">True</property>\
        <property name=\"hexpand\">True</property>\
        <property name=\"vexpand\">True</property>\
        <property name=\"shadow_type\">out</property>\
        <child>\
          <object class=\"GtkTextView\" id=\"tv_comment\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">True</property>\
          </object>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">True</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">1</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkBox\" id=\"vb_complex_details\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <property name=\"no_show_all\">True</property>\
        <property name=\"orientation\">vertical</property>\
        <child>\
          <object class=\"GtkLabel\" id=\"lbl_reproducible\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
            <property name=\"label\" translatable=\"yes\">How reproducible is this problem\?</property>\
            <property name=\"angle\">0.02</property>\
            <property name=\"xalign\">0</property>\
          </object>\
          <packing>\
            <property name=\"expand\">False</property>\
            <property name=\"fill\">True</property>\
            <property name=\"position\">0</property>\
          </packing>\
        </child>\
        <child>\
          <object class=\"GtkComboBoxText\" id=\"cmb_reproducible\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
          </object>\
          <packing>\
            <property name=\"expand\">False</property>\
            <property name=\"fill\">True</property>\
            <property name=\"position\">1</property>\
          </packing>\
        </child>\
        <child>\
          <object class=\"GtkLabel\" id=\"lbl_steps\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
            <property name=\"label\" translatable=\"yes\">How it can be reproduced (one step per line)\?</property>\
            <property name=\"xalign\">0</property>\
          </object>\
          <packing>\
            <property name=\"expand\">False</property>\
            <property name=\"fill\">True</property>\
            <property name=\"position\">2</property>\
          </packing>\
        </child>\
        <child>\
          <object class=\"GtkScrolledWindow\" id=\"sw_steps\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">True</property>\
            <property name=\"hexpand\">True</property>\
            <property name=\"vexpand\">True</property>\
            <property name=\"shadow_type\">out</property>\
            <child>\
              <object class=\"GtkTextView\" id=\"tv_steps\">\
                <property name=\"visible\">True</property>\
                <property name=\"can_focus\">True</property>\
              </object>\
            </child>\
          </object>\
          <packing>\
            <property name=\"expand\">True</property>\
            <property name=\"fill\">True</property>\
            <property name=\"position\">3</property>\
          </packing>\
        </child>\
        <child>\
          <object class=\"GtkEventBox\" id=\"eb_complex_details\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
            <child>\
              <object class=\"GtkLabel\" id=\"lbl_complex_details_hint\">\
                <property name=\"visible\">True</property>\
                <property name=\"can_focus\">False</property>\
                <property name=\"label\" translatable=\"yes\">Please add a comprehensive description of the problem you have. This is a very long place holder.</property>\
                <property name=\"wrap\">True</property>\
                <property name=\"xalign\">0</property>\
                <attributes>\
                  <attribute name=\"weight\" value=\"bold\"/>\
                </attributes>\
              </object>\
            </child>\
          </object>\
          <packing>\
            <property name=\"expand\">False</property>\
            <property name=\"fill\">True</property>\
            <property name=\"position\">4</property>\
          </packing>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">True</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">3</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkBox\" id=\"vb_simple_details\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <property name=\"no_show_all\">True</property>\
        <property name=\"orientation\">vertical</property>\
        <child>\
          <object class=\"GtkEventBox\" id=\"eb_comment\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
            <child>\
              <object class=\"GtkLabel\" id=\"label5\">\
                <property name=\"visible\">True</property>\
                <property name=\"can_focus\">False</property>\
                <property name=\"label\" translatable=\"yes\">You need to fill the how to before you can proceed...</property>\
                <property name=\"single_line_mode\">True</property>\
              </object>\
            </child>\
          </object>\
          <packing>\
            <property name=\"expand\">False</property>\
            <property name=\"fill\">True</property>\
            <property name=\"position\">0</property>\
          </packing>\
        </child>\
        <child>\
          <object class=\"GtkLabel\" id=\"label3\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
            <property name=\"halign\">start</property>\
            <property name=\"valign\">start</property>\
            <property name=\"label\" translatable=\"yes\">&lt;b&gt;Your comments are not private.&lt;/b&gt; They may be included into publicly visible problem reports.</property>\
            <property name=\"use_markup\">True</property>\
            <property name=\"wrap\">True</property>\
          </object>\
          <packing>\
            <property name=\"expand\">False</property>\
            <property name=\"fill\">True</property>\
            <property name=\"position\">1</property>\
          </packing>\
        </child>\
        <child>\
          <object class=\"GtkCheckButton\" id=\"cb_no_comment\">\
            <property name=\"label\" translatable=\"yes\">I don't know what caused this problem</property>\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">True</property>\
            <property name=\"receives_default\">False</property>\
            <property name=\"halign\">start</property>\
            <property name=\"draw_indicator\">True</property>\
          </object>\
          <packing>\
            <property name=\"expand\">False</property>\
            <property name=\"fill\">True</property>\
            <property name=\"position\">2</property>\
          </packing>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">4</property>\
      </packing>\
    </child>\
  </object>\
  <object class=\"GtkBox\" id=\"page_1\">\
    <property name=\"orientation\">vertical</property>\
    <property name=\"visible\">True</property>\
    <property name=\"can_focus\">False</property>\
    <property name=\"border_width\">10</property>\
    <property name=\"spacing\">3</property>\
    <child>\
      <object class=\"GtkBox\" id=\"vb_workflows\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <property name=\"orientation\">vertical</property>\
        <child>\
          <placeholder/>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">0</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkScrolledWindow\" id=\"scrolledwindow2\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">True</property>\
        <property name=\"shadow_type\">in</property>\
        <child>\
          <object class=\"GtkViewport\" id=\"viewport1\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
            <child>\
              <object class=\"GtkBox\" id=\"vb_events\">\
                <property name=\"orientation\">vertical</property>\
                <property name=\"visible\">True</property>\
                <property name=\"can_focus\">False</property>\
                <property name=\"no_show_all\">True</property>\
                <child>\
                  <placeholder/>\
                </child>\
              </object>\
            </child>\
          </object>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">True</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">1</property>\
      </packing>\
    </child>\
  </object>\
  <object class=\"GtkBox\" id=\"page_4\">\
    <property name=\"orientation\">vertical</property>\
    <property name=\"visible\">True</property>\
    <property name=\"can_focus\">False</property>\
    <property name=\"border_width\">10</property>\
    <property name=\"spacing\">3</property>\
    <child>\
      <object class=\"GtkBox\">\
        <property name=\"visible\">True</property>\
        <property name=\"spacing\">6</property>\
        <child>\
          <object class=\"GtkLabel\" id=\"label4\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
            <property name=\"halign\">start</property>\
            <property name=\"label\" translatable=\"yes\">Size:</property>\
            <property name=\"justify\">right</property>\
            <attributes>\
              <attribute name=\"weight\" value=\"bold\"/>\
            </attributes>\
          </object>\
        </child>\
        <child>\
          <object class=\"GtkLabel\" id=\"lbl_size\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">False</property>\
            <property name=\"halign\">start</property>\
          </object>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">False</property>\
        <property name=\"position\">0</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkScrolledWindow\" id=\"container_details2\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">True</property>\
        <property name=\"shadow_type\">out</property>\
        <child>\
          <object class=\"GtkTreeView\" id=\"tv_details\">\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">True</property>\
            <child internal-child=\"selection\">\
              <object class=\"GtkTreeSelection\" id=\"treeview-selection\"/>\
            </child>\
          </object>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">True</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">1</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkBox\" id=\"box1\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <child>\
          <object class=\"GtkButton\" id=\"btn_add_file\">\
            <property name=\"label\" translatable=\"yes\">Attach a file</property>\
            <property name=\"visible\">True</property>\
            <property name=\"can_focus\">True</property>\
            <property name=\"receives_default\">True</property>\
          </object>\
          <packing>\
            <property name=\"expand\">False</property>\
            <property name=\"fill\">False</property>\
            <property name=\"position\">0</property>\
          </packing>\
        </child>\
        <child>\
          <placeholder/>\
        </child>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">2</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkCheckButton\" id=\"cb_approve_bt\">\
        <property name=\"label\" translatable=\"yes\">I reviewed the data and _agree with submitting it</property>\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">True</property>\
        <property name=\"receives_default\">False</property>\
        <property name=\"tooltip_text\" translatable=\"yes\">If you are reporting to a remote server, make sure you removed all private data (such as usernames and passwords). Backtrace, command line, environment variables are the typical items in need of examining.</property>\
        <property name=\"halign\">start</property>\
        <property name=\"use_underline\">True</property>\
        <property name=\"draw_indicator\">True</property>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">3</property>\
      </packing>\
    </child>\
  </object>\
  <object class=\"GtkBox\" id=\"page_5\">\
    <property name=\"margin\">18</property>\
    <property name=\"visible\">True</property>\
    <property name=\"orientation\">vertical</property>\
    <property name=\"spacing\">12</property>\
    <child>\
      <object class=\"GtkStack\">\
        <property name=\"visible\">True</property>\
        <property name=\"homogeneous\">False</property>\
        <child>\
          <object class=\"GtkBox\" id=\"report-status-box\">\
            <property name=\"spacing\">6</property>\
            <child>\
              <object class=\"GtkSpinner\" id=\"spinner_event_log\">\
                <property name=\"active\">True</property>\
              </object>\
            </child>\
            <child>\
              <object class=\"GtkImage\" id=\"img_process_fail\">\
                <property name=\"no_show_all\">True</property>\
                <property name=\"icon_name\">dialog-warning-symbolic</property>\
                <property name=\"icon_size\">1</property>\
              </object>\
            </child>\
            <child>\
              <object class=\"GtkLabel\" id=\"lbl_event_log\">\
                <property name=\"visible\">True</property>\
                <property name=\"halign\">start</property>\
                <property name=\"label\" translatable=\"yes\">Processing did not start yet</property>\
                <property name=\"use_markup\">True</property>\
                <property name=\"justify\">fill</property>\
                <property name=\"wrap\">True</property>\
              </object>\
            </child>\
          </object>\
        </child>\
      </object>\
    </child>\
    <child>\
      <object class=\"GtkBox\" id=\"report-warning-label-box\">\
        <property name=\"no-show-all\">True</property>\
        <property name=\"orientation\">vertical</property>\
      </object>\
    </child>\
    <child>\
      <object class=\"GtkExpander\" id=\"expand_report\">\
        <property name=\"can_focus\">True</property>\
        <property name=\"no_show_all\">True</property>\
        <child>\
          <object class=\"GtkScrolledWindow\">\
            <property name=\"visible\">True</property>\
            <property name=\"shadow-type\">out</property>\
            <child>\
              <object class=\"GtkViewport\">\
                <property name=\"visible\">True</property>\
                <child>\
                  <object class=\"GtkTextView\" id=\"tv_event_log\">\
                    <property name=\"expand\">True</property>\
                    <property name=\"visible\">True</property>\
                    <property name=\"editable\">False</property>\
                  </object>\
                </child>\
              </object>\
            </child>\
          </object>\
        </child>\
        <child type=\"label\">\
          <object class=\"GtkLabel\">\
            <property name=\"visible\">True</property>\
            <property name=\"label\" translatable=\"yes\">Show log</property>\
          </object>\
        </child>\
      </object>\
    </child>\
  </object>\
  <object class=\"GtkBox\" id=\"page_6\">\
    <property name=\"orientation\">vertical</property>\
    <property name=\"visible\">True</property>\
    <property name=\"can_focus\">False</property>\
    <property name=\"border_width\">10</property>\
    <property name=\"spacing\">3</property>\
    <child>\
      <object class=\"GtkLabel\" id=\"label2\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <property name=\"halign\">start</property>\
        <property name=\"valign\">start</property>\
        <property name=\"label\" translatable=\"yes\">Reporting has finished. You can close this window now.</property>\
        <property name=\"wrap\">True</property>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">0</property>\
      </packing>\
    </child>\
    <child>\
      <object class=\"GtkLabel\" id=\"label6\">\
        <property name=\"visible\">True</property>\
        <property name=\"can_focus\">False</property>\
        <property name=\"halign\">start</property>\
        <property name=\"valign\">start</property>\
        <property name=\"label\" translatable=\"yes\">If you want to report the problem to a different destination, collect additional information, or provide a better problem description and repeat reporting process, press 'Forward'.</property>\
        <property name=\"wrap\">True</property>\
      </object>\
      <packing>\
        <property name=\"expand\">False</property>\
        <property name=\"fill\">True</property>\
        <property name=\"position\">1</property>\
      </packing>\
    </child>\
    <child>\
      <placeholder/>\
    </child>\
  </object>\
  <object class=\"GtkBox\" id=\"page_7\">\
    <property name=\"orientation\">vertical</property>\
    <property name=\"visible\">True</property>\
    <property name=\"can_focus\">False</property>\
    <property name=\"border_width\">10</property>\
    <property name=\"spacing\">3</property>\
    <child>\
      <placeholder/>\
    </child>\
    <child>\
      <placeholder/>\
    </child>\
    <child>\
      <placeholder/>\
    </child>\
  </object>\
</interface>\
"
